import { motion } from 'framer-motion'

export default function Hero(){
  return (
    <section id="home" className="min-h-screen flex items-center">
      <div className="max-w-5xl mx-auto px-6 py-28 grid md:grid-cols-2 gap-12 items-center">
        <div>
          <motion.h1 initial={{opacity:0, y:12}} animate={{opacity:1, y:0}} transition={{delay:0.1}} className="text-5xl font-extrabold leading-tight">Harsh Ledwani</motion.h1>
          <motion.p initial={{opacity:0}} animate={{opacity:1}} transition={{delay:0.25}} className="mt-4 text-lg text-slate-300">Full Stack Developer & AI Enthusiast — building resilient, production-ready web apps and sync systems that prioritize reliability and user experience.</motion.p>

          <motion.div className="mt-8 flex gap-4" initial={{opacity:0}} animate={{opacity:1}} transition={{delay:0.4}}>
            <a href="#projects" className="px-5 py-3 rounded-md bg-primary text-white font-semibold">View Projects</a>
            <a href="#contact" className="px-5 py-3 rounded-md border border-slate-700 text-slate-200">Contact Me</a>
          </motion.div>

        </div>

        <motion.div initial={{scale:0.98, opacity:0}} animate={{scale:1, opacity:1}} transition={{delay:0.35}} className="relative w-72 h-72 md:w-96 md:h-96 rounded-2xl overflow-hidden bg-gradient-to-br from-primary to-accent animate-slow-tilt shadow-2xl">
          {/* Placeholder illustration */}
          <div className="absolute inset-0 flex items-center justify-center text-slate-900 font-bold">HL</div>
        </motion.div>
      </div>
    </section>
  )
}
