import { resume } from '../data/resume'
import { motion } from 'framer-motion'

export default function Education(){
  return (
    <section id="education" className="py-20">
      <div className="max-w-3xl mx-auto px-6">
        <motion.h2 initial={{opacity:0, y:6}} animate={{opacity:1, y:0}} className="text-3xl font-bold mb-4">Education</motion.h2>

        <div className="mt-6 space-y-4 text-slate-300">
          {resume.education.map((e) => (
            <motion.div key={e.institution} initial={{opacity:0, y:8}} whileInView={{opacity:1, y:0}} viewport={{once:true}} className="bg-slate-800 p-4 rounded-lg">
              <h4 className="text-white font-semibold">{e.degree} — {e.institution}</h4>
              <div className="text-slate-400 text-sm">{e.range} • {e.location}</div>
              <p className="mt-2 text-sm">{e.details}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
