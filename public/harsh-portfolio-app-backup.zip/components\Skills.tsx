import { resume } from '../data/resume'
import { motion } from 'framer-motion'
import { FaCircle, FaReact, FaNodeJs, FaPython, FaDatabase, FaCode, FaLayerGroup } from 'react-icons/fa'
import { SiNextdotjs, SiTailwindcss, SiPostgresql, SiMongodb, SiGit, SiVisualstudiocode, SiGooglecolab, SiJavascript, SiHtml5, SiCss3, SiJava, SiCplusplus, SiPytorch } from 'react-icons/si'
import { IconType } from 'react-icons'

const iconMap: Record<string, IconType> = {
  'React.js': FaReact,
  'Next.js': SiNextdotjs,
  'Tailwind CSS': SiTailwindcss,
  'TypeScript': FaCode,
  'Node.js': FaNodeJs,
  'Python': FaPython,
  'PostgreSQL': SiPostgresql,
  'MongoDB': SiMongodb,
  'MySQL': FaDatabase,
  'Pandas': FaLayerGroup,
  'NumPy': FaLayerGroup,
  'Scikit-learn': FaLayerGroup,
  'PyTorch': SiPytorch,
  'Git': SiGit,
  'GitHub': SiGit,
  'Visual Studio Code': SiVisualstudiocode,
  'Google Colab': SiGooglecolab,
  'JavaScript': SiJavascript,
  'HTML5': SiHtml5,
  'CSS3': SiCss3,
  'Java': SiJava,
  'C++': SiCplusplus,
  'Data Structures & Algorithms': FaProjectDiagram,
  'Object-Oriented Programming': FaProjectDiagram,
  'Database Management Systems': FaDatabase,
  'Operating Systems': FaCode,
}

function getIconFor(item: string){
  const name = item.replace(/\s*\(.*\)/,'').trim()
  if(iconMap[name]) return iconMap[name]
  for(const key of Object.keys(iconMap)){
    const candidate = iconMap[key]
    if(name.toLowerCase().includes(key.toLowerCase()) && candidate) return candidate
  }
  return FaCircle
}

export default function Skills(){
  return (
    <section id="skills" className="py-20 bg-slate-900">
      <div className="max-w-4xl mx-auto px-6">
        <motion.h2 initial={{opacity:0, y:6}} animate={{opacity:1, y:0}} className="text-3xl font-bold mb-4 text-white">Skills</motion.h2>

        <div className="grid md:grid-cols-3 gap-6 mt-6">
          {Object.entries(resume.skills).map(([category, items]) => (
            <motion.div key={category} initial={{opacity:0, y:8}} animate={{opacity:1, y:0}} transition={{delay:0.05}} className="p-4 bg-slate-800 rounded-lg">
              <h4 className="text-white font-semibold">{category}</h4>
              <ul className="text-slate-300 mt-2 space-y-1 text-sm">
                {items.map((s: string) => {
                  const Icon = getIconFor(s)
                  return (
                    <li key={s} className="flex items-center gap-3">
                      <Icon size={16} className="text-primary flex-shrink-0" aria-hidden="true" />
                      <span>{s}</span>
                    </li>
                  )
                })}
              </ul>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
