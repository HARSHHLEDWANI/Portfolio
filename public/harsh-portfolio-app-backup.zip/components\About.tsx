import { resume } from '../data/resume'
import { motion } from 'framer-motion'

export default function About(){
  return (
    <section id="about" className="py-20">
      <div className="max-w-4xl mx-auto px-6">
        <motion.h2 initial={{opacity:0, y:6}} animate={{opacity:1, y:0}} className="text-3xl font-bold mb-4">About</motion.h2>
        <motion.p initial={{opacity:0}} animate={{opacity:1}} transition={{delay:0.1}} className="text-slate-300">{resume.summary}</motion.p>

        <div className="mt-6 grid md:grid-cols-3 gap-4">
          <div className="md:col-span-2">
            <h4 className="text-white font-semibold">Focus Areas</h4>
            <ul className="text-slate-300 mt-2 list-disc list-inside">
              <li>Production-ready web applications (React, Next.js)</li>
              <li>Offline-first sync & reliability patterns</li>
              <li>ML-powered tooling & data pipelines</li>
            </ul>
          </div>

          <div className="bg-slate-800 p-4 rounded-lg">
            <h4 className="text-white">Contact</h4>
            <p className="text-slate-300 text-sm mt-2">{resume.contact.email} • {resume.contact.phone}</p>
            <div className="mt-3 flex gap-2">
              <a href={resume.contact.github} className="text-slate-200 underline">GitHub</a>
              <a href={resume.contact.linkedin} className="text-slate-200 underline">LinkedIn</a>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
