import { resume } from '../data/resume'
import { motion } from 'framer-motion'

export default function Experience(){
  return (
    <section id="experience" className="py-20 bg-slate-900">
      <div className="max-w-4xl mx-auto px-6">
        <motion.h2 initial={{opacity:0, y:6}} animate={{opacity:1, y:0}} className="text-3xl font-bold mb-4 text-white">Experience</motion.h2>

        <div className="mt-6 space-y-6">
          {resume.experience.map((exp) => (
            <motion.div key={exp.company} initial={{opacity:0, y:8}} whileInView={{opacity:1, y:0}} viewport={{once:true}} className="bg-slate-800 p-4 rounded-lg">
              <div className="flex items-start justify-between">
                <div>
                  <h4 className="text-white font-semibold">{exp.title} — {exp.company}</h4>
                  <div className="text-slate-400 text-sm">{exp.range} • {exp.location}</div>
                </div>
              </div>

              <ul className="mt-3 list-disc list-inside text-slate-300 text-sm">
                {exp.responsibilities.map((r: string, idx: number) => <li key={idx}>{r}</li>)}
              </ul>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
