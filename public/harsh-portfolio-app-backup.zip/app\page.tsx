import Hero from '../components/Hero'
import About from '../components/About'
import Skills from '../components/Skills'
import Projects from '../components/Projects'
import Experience from '../components/Experience'
import Education from '../components/Education'
import ContactForm from '../components/ContactForm'

export default function Home(){
  return (
    <main className="min-h-screen">
      <Hero />
      <div className="divide-y divide-slate-700">
        <About />
        <Skills />
        <Projects />
        <Experience />
        <Education />
        <section id="contact" className="py-20">
          <div className="max-w-3xl mx-auto px-6">
            <h2 className="text-3xl font-bold mb-4">Contact</h2>
            <p className="text-slate-300 mb-6">Want to work together or chat about opportunities? Drop a message below.</p>
            <ContactForm />
          </div>
        </section>
      </div>
    </main>
  )
}
