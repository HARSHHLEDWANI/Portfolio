import { resume } from '../data/resume'
import { motion } from 'framer-motion'

export default function Projects(){
  return (
    <section id="projects" className="py-20">
      <div className="max-w-5xl mx-auto px-6">
        <motion.h2 initial={{opacity:0, y:6}} animate={{opacity:1, y:0}} className="text-3xl font-bold mb-4">Projects</motion.h2>

        <div className="grid md:grid-cols-2 gap-6 mt-6">
          {resume.projects.map((p) => (
            <motion.article key={p.title} initial={{opacity:0, y:10}} whileInView={{opacity:1, y:0}} viewport={{once:true}} className="bg-slate-800 p-5 rounded-lg">
              <h3 className="text-xl font-semibold text-white">{p.title}</h3>
              <p className="text-slate-300 mt-2 text-sm">{p.summary}</p>

              <div className="mt-3 flex items-center justify-between">
                <div className="text-xs text-slate-400">{p.stack.join(' • ')}</div>
                <div className="flex gap-2">
                  {p.source && <a href={p.source} className="text-slate-200 underline text-sm">Source</a>}
                  {p.live && <a href={p.live} className="text-slate-200 underline text-sm">Live</a>}
                </div>
              </div>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  )
}
