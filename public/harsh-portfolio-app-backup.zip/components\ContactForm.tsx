import { useState } from 'react'

export default function ContactForm(){
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [message, setMessage] = useState('')
  const [status, setStatus] = useState<'idle'|'sending'|'sent'|'error'>('idle')

  async function handleSubmit(e: any){
    e.preventDefault()
    setStatus('sending')
    try{
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({name, email, message})
      })

      if(res.ok){
        setStatus('sent')
        setName('')
        setEmail('')
        setMessage('')
      } else {
        setStatus('error')
      }
    }catch(err){
      setStatus('error')
    }
  }

  return (
    <form onSubmit={handleSubmit} className="max-w-2xl mx-auto grid gap-3">
      <input className="p-3 bg-slate-800 rounded text-slate-200" placeholder="Name" value={name} onChange={(e)=>setName(e.target.value)} />
      <input className="p-3 bg-slate-800 rounded text-slate-200" placeholder="Email" value={email} onChange={(e)=>setEmail(e.target.value)} />
      <textarea className="p-3 bg-slate-800 rounded text-slate-200" placeholder="Message" rows={6} value={message} onChange={(e)=>setMessage(e.target.value)} />
      <div className="flex items-center justify-between">
        <button className="bg-indigo-500 px-4 py-2 rounded text-white" disabled={status==='sending'}>{status==='sending' ? 'Sending...' : 'Send'}</button>
        {status==='sent' && <div className="text-green-400">Message sent ✅</div>}
        {status==='error' && <div className="text-red-400">Something went wrong</div>}
      </div>
    </form>
  )
}
