/** @type {import('next').NextConfig} */
const nextConfig = {
  experimental: { appDir: true },
  reactStrictMode: true,
  images: {
    domains: ["images.unsplash.com", "placehold.co"],
  },
}
module.exports = nextConfig
