import { NextResponse } from 'next/server'

export async function POST(req: Request){
  try{
    const body = await req.json()
    const { name, email, message } = body
    if(!name || !email || !message) return NextResponse.json({error: 'Missing fields'}, {status:400})

    // For now just log. Integrate with an email provider (SendGrid, Mailgun) or serverless function later.
    console.log('Contact form submission:', {name, email, message})

    return NextResponse.json({ok: true})
  }catch(err){
    console.error(err)
    return NextResponse.json({error: 'Server error'}, {status:500})
  }
}
