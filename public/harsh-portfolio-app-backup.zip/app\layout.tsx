import './globals.css'
import React from 'react'
import Navbar from '../components/Navbar'

export const metadata = {
  title: 'Harsh Ledwani — Full Stack Developer & AI Enthusiast',
  description: 'I craft modern web apps & AI-powered experiences. Full Stack Developer focused on performance, accessibility, and ML integrations.'
}

export default function RootLayout({ children }: { children: React.ReactNode }){
  return (
    <html lang="en">
      <body className="bg-slate-900 text-slate-100 antialiased">
        <a href="#main" className="sr-only focus:not-sr-only p-2">Skip to content</a>
        <Navbar />
        <main id="main">{children}</main>
      </body>
    </html>
  )
}
